$(document).ready(function(){

	//Toggle Between Password See and Hide
	$(document).on('click', '.view-pass', function(){
		if( $('#password').attr('type') == 'password') {
			$('#password').attr('type', 'text');
			$('.view-pass .fa').removeClass('fa-eye').addClass('fa-eye-slash');
		} else {
			$('#password').attr('type', 'password');
			$('.view-pass .fa').removeClass('fa-eye-slash').addClass('fa-eye');
		}
	});

	//Masking the Input Fields With Correct Formate
	$("#phone").mask("999 999 9999", {clearIfNotMatch: true, placeholder:""});
	$("#winticket").mask("99-99-99-99-99", {clearIfNotMatch: true, placeholder:""});
	$(".win-ticket-section input[type='number']").mask("99", {clearIfNotMatch: true, placeholder:""});

	//Footer Fix If Body Height Is Less Then Window Hirght
	var winH = $(window).height();
	var eleH = $("body").height();
	( eleH < winH ) ? $("footer").addClass("fix-footer") : console.log('Body Full');

	//Initializing Data Table
    $('#pend-tick, #paid-tick, #draw-tick, #user-table').DataTable();

    //Get User History On Click History Button
    $(document).on('click', '#user-history', function(){
    	$(".ajax-loader").show();
    	$.post(baseUrl + 'authajax/user-history', {"id": $(this).attr("data-id")} ,function(response){
    		$(".ajax-loader").hide();
    		$("#history").html(response);
    		$("#ajxModal").modal();
    	});
    });

     //Get Draw History On Click History Button
    $(document).on('click', '#draw-history', function(){
    	$(".ajax-loader").show();
    	$.post(baseUrl + 'authajax/draw-history', {"id": $(this).attr("data-id")} ,function(response){
    		$(".ajax-loader").hide();
    		$("#history").html(response);
    		$("#ajxModal").modal();
    	});
    });

    //Initially Disable Input On Click Enable For Update
    $("#option-form :input").prop('disabled', true);
	$(document).on('click', '.enable-edit', function(){
		$("#option-form :input").prop('disabled', false);
	});

});