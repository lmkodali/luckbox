//Loader Up Onload Front Page
window.onload = function() {
	setTimeout(function(){
		$(".pre-screen-loader").fadeOut(1000, function(){
		});
	}, 1500)
}

$(function(){
	//Close Side Navigation When Click Close Icon or Click Other Than Nav
	$(document).on('click', '.side-nav-close, .body-overlay', function(){
		$('.side-nav').animate({left: '-275px'});
		$('.body-overlay').fadeOut(300);
		$('.side-nav-close').fadeOut(80);
	});
	//Open Side Navigation With Animated
	$(document).on('click', '.open-nav', function(){
		$('.side-nav').animate({left: '0px'});
		$('.body-overlay').fadeIn(300);
		$('.side-nav-close').fadeIn(80);
	});
	//Toggle Between Password See and Hide
	$(document).on('click', '.view-pass', function(){
		if( $('#password').attr('type') == 'password') {
			$('#password').attr('type', 'text');
			$('.view-pass .fa').removeClass('fa-eye').addClass('fa-eye-slash');
		} else {
			$('#password').attr('type', 'password');
			$('.view-pass .fa').removeClass('fa-eye-slash').addClass('fa-eye');
		}
	});
	//Masking the Input Fields With Correct Formate
	$("#phone").mask("999 999 9999", {clearIfNotMatch: true, placeholder:""});
	$(".ticketnum").mask("99", {clearIfNotMatch: true, placeholder:""});
	$("#ccnum").mask("9999 9999 9999 9999", {clearIfNotMatch: true, placeholder:""});
	$("#exp").mask("99/99", {clearIfNotMatch: true, placeholder:""});
	$("#cvvnum").mask("9999", {clearIfNotMatch: false, placeholder:""});
});


