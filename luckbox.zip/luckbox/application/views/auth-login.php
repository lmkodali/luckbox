<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-sm-offset-4">
				<div class="panel panel-default login-panel">
					<div class="panel-heading">Administator Login</div>
				</div>
				<?php
					echo (validation_errors() != false) ? '<div class="bg-danger">'.validation_errors().'</div>' : '' ;
					echo get_msg();	
					echo form_open('auth/login', ['autocomplete' => 'off']);
					?>
					<div class="form-group">
						<?php
							echo form_label('Email', 'email');
							echo form_input([
									'type'		=> 'email',
									'name' 		=> 'email',
									'id'		=> 'email',
									'value'		=> set_value('email'),
									'class'		=> 'form-control',
									'required' 	=> 'required'
								]);
						?>
					</div>
					<div class="form-group">
						<?php
							echo form_label('Password', 'password');
							echo form_password([
									'name' 		=> 'password',
									'id'		=> 'password',
									'class'		=> 'form-control',
									'required' 	=> 'required'
								]);
						?>
					</div>
					<div class="form-group">
						<p class="text-center"><?= 
							form_submit([
									'name' 	=> 'login',
									'value'	=> 'Log In',
									'class'	=> 'btn btn-primary btn-block'
								]);
						?></p>
					</div>
				<?= form_close(); ?>
			</div>
		</div>
	</div>