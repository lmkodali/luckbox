<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>
			<?php
				if( page_name(1) == 'login' || page_name(1) == 'signup' || page_name(1) == 'verify'){
					$page = 1;
				} else {
					$page = 2;
				}
				echo get_user_title($page);
			?>
		</title>
		<?php
			echo link_tag('favicon.png', 'shortcut icon', 'image/png');
			echo link_tag('assets/css/bootstrap.min.css', 'stylesheet', 'text/css');
			echo link_tag('assets/css/font-awesome.min.css', 'stylesheet', 'text/css');
			echo link_tag('https://fonts.googleapis.com/css?family=Open+Sans:400,600,700', 'stylesheet', 'text/css');
			echo link_tag('assets/css/style.css', 'stylesheet', 'text/css');
			echo link_tag('assets/css/odometer-theme-car.css', 'stylesheet', 'text/css');
		?>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/jquery-1.12.4.min.js'); ?>"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
		
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/script.js'); ?>"></script>
		<script type="text/javascript" src="<?= base_url('assets/js/odometer.js'); ?>"></script>
	</head>
	<body>
		<?php if( isset($user_loggedin) && $user_loggedin == TRUE ): ?>
			<?php
				$profile_pic = ( isset($fb_logout) ) ? $user_pic : base_url('assets/images/'.$user_pic);
			?>
			<div class="body-overlay"></div>
			<div class="side-nav">
				<span class="side-nav-close">&times;</span>
				<div class="top-info white-with-shade">
					<h3><img src="<?= $profile_pic; ?>"> <?= $user_name; ?></h3>
					<p><?= $user_email; ?></p>
				</div>
				<ul>
					<li><?= anchor(base_url(), '<i class="fa fa-home"></i> Home'); ?></li>
					<li><a href="<?= base_url('user/tickets'); ?>"><i class="fa fa-ticket"></i> Current Tickets <?= ( $ticket_count != 0 ) ? '<span class="badge pull-right">'.$ticket_count.'</span>' : ''; ?></a></li>
					<li><?= anchor('user/history', '<i class="fa fa-history"></i> History'); ?></li>
					<li><?= anchor('user/account', '<i class="fa fa-user-circle"></i> Account'); ?></li>
					<li><?= anchor('user/logout', '<i class="fa fa-power-off"></i> Log Out'); ?></li>
				</ul>
			</div>
		<?php endif; ?>

		<?php if( isset($user_loggedin) && $user_loggedin == TRUE && isset($is_verified) && $is_verified == "no" ): ?>
				<div class="verify-number-popup" ng-app="myPhVerifyApp" ng-controller="myPhVerifyController">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
								<div class="popup-inner">
									<h4>Please Verify Your Phone Number</h4>
									<div class="change-phone">
										<div class="row">
											<div class="col-xs-9">
												<div class="form-group">
													<label for="changenum"><?= (isset($fb_logout)) ? 'Enter Your Phone Number ( we will send you a code )' : 'Want to change enter new ?'; ?></label>
													<div class="input-group">
														<span class="input-group-addon"><?= COUNTRY_CODE; ?></span>
														<input type="text" name="changenum" class="form-control newnum" ng-model="phoneNumber">
													</div>
												</div>
											</div>
											<div class="col-xs-3">
												<div class="form-group">
													<button class="btn-my btn-blue" ng-click="updateAndSendOTP()">Send</button>
												</div>
											</div>
										</div>
									</div><!-- End Change Phone -->
									<div class="verify-phone-num">
										<div class="row">
											<div class="col-xs-9">
												<div class="form-group">
													<label for="changenum">Enter Recieved Code <span class="pull-right"><a href="javascript:void(0);" ng-click="resendCode()">Resend Code</a></span></label>
													<div class="clearfix"></div>
													<input type="text" name="verifycode" class="form-control" ng-model="verifycode">
												</div>
											</div>
											<div class="col-xs-3">
												<div class="form-group">
													<button class="btn-my btn-blue" ng-click="verifyOTP()">Verify</button>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
					<script type="text/javascript">
						$(".newnum").mask("999 999 9999", {clearIfNotMatch: true, placeholder:""});
						// Create angular app myVerifyApp
						var app = angular.module('myPhVerifyApp', []);
						// Create angular controller myVerifyController
						app.controller('myPhVerifyController', ['$scope', '$http', function($scope, $http){
							$scope.updateAndSendOTP = function(){
								$http.post('<?= base_url('outer/update-verify-phone'); ?>', {
									"newphone": $scope.phoneNumber,
									"id": <?= $this->session->userdata('userid'); ?>
								}).then(function(response){
									if( response.data.error == "false"){
										$scope.phoneNumber = '';
										alert('Number Updated and OTP sent.');
									} else {
										alert(response.data.error);
									}
								});
							}

							// Resend verification code
							$scope.resendCode = function() {
								$http.post('<?= base_url('outer/resend-verify-code'); ?>').then(function(response){
										if( response.data.error == "false" ) {
											alert('Verification code sent again.');
										} else {
											alert('Unable to send verification code again.');
										}
									});
							}

							$scope.verifyOTP = function() {
								if( $scope.verifycode != ''){
									$http.post('<?= base_url('apps/verify-phone'); ?>', {
												"codeveri": $scope.verifycode
											}
										).then(function(response){
										if( response.data.error == "false" ) {
											window.location.href="<?= base_url(); ?>";
										} else {
											alert('Sorry unable to verify enter valid code.');
										}
									});
								}
							}

						}]);
					</script>
		<?php endif;?>