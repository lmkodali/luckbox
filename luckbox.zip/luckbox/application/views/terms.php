<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="full-section">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<h1 class="text-center">Terms &amp; Conditions</h1>
			</div>
		</div>
	</div>
</section>