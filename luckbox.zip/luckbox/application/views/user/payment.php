<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section" ng-app="payUserApp" ng-controller="payUserCtrl">
		<div class="pay-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<h1><img src="<?= base_url('assets/images/buy-ticket.png'); ?>" width="50" height="50" alt="BuyTickets"> Buy Tickets</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="payment-gateway white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?php
							echo form_open('user/payment', ['autocomplete' => 'off'], ['totalamount' => $totalamount, 'addcard' => '1']);
							echo (validation_errors() != false) ? '<div class="val-errors">'.validation_errors().'</div>' : '';
							echo get_msg();
							?>
							<div class="row">
								<div class="col-xs-12">
									<div class="form-group">
										<?php echo form_label('Saved Cards', 'savedcards'); ?>
										<select name="savedcards" class="form-control" id="savedcards">
											<?php if( $savedCards->num_rows() > 0 ): ?>
												<option value="0">Choose Card Or Add New</option>
												<?php foreach( $savedCards->result() as $card): ?>
													<option value="<?= $card->Id ?>">
														<?php echo mask_card_number($card->Number).' ('.$card->Name.')'; ?>
													</option>
												<?php endforeach;?>
											<?php else: ?>
												<option value="0" selected>No Saved Card, Add Below</option>
											<?php endif; ?>
										</select>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<?php
											echo form_label('Name on Card *', 'cardname');
											echo form_input([
													'name' 		=> 'cardname',
													'id' 		=> 'cardname',
													'class' 	=> 'form-control',
													'value' 	=> set_value('cardname'),
													'required'	=> 'required'
												]);
										?>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<?php
											echo form_label('Credit Card Number *', 'ccnum');
											echo form_input([
													'name' 		=> 'ccnum',
													'id' 		=> 'ccnum',
													'maxlength' => '19',
													'class' 	=> 'form-control',
													'value' 	=> set_value('ccnum'),
													'required'	=> 'required'
												]);
										?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-xs-12">
									<div class="form-group">
										<?php
											echo form_label('Exp Date *', 'exp');
											echo form_input([
													'name' 			=> 'exp',
													'id' 			=> 'exp',
													'class' 		=> 'form-control',
													'placeholder' 	=> 'MM/YY',
													'value' 		=> set_value('exp'),
													'required'		=> 'required'
												]);
										?>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<?php
											echo form_label('CVV *', 'cvvnum');
											echo form_input([
													'type'		=> 'number',
													'name' 		=> 'cvvnum',
													'id' 		=> 'cvvnum',
													'maxlength' => '4',
													'class' 	=> 'form-control',
													'value' 	=> set_value('cvvnum'),
													'required'	=> 'required'
												]);
										?>
									</div>
								</div>
								<div class="col-xs-12">
									<div class="form-group">
										<?php
											echo form_label('Billing Postal Code *', 'zipcode');
											echo form_input([
													'name' 		=> 'zipcode',
													'id' 		=> 'zipcode',
													'maxlength' => '6',
													'class' 	=> 'form-control',
													'value' 	=> set_value('zipcode'),
													'required'	=> 'required'
												]);
										?>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="form-group">
										<div class="next-step">
											<?php
												echo form_submit('pay', 'Pay', ['class' => 'btn-my btn-blue pay-btn'])
											?>
										</div>
									</div>
								</div>
							</div>
							<?php
							echo form_close();
						?>
					</div><!-- End Column -->
				</div>
			</div>
		</div><!--End Payment Gateway-->
	</section>
	<script type="text/javascript">
		var app = angular.module('payUserApp', []);
		app.controller('payUserCtrl', function($scope, $http){
			$scope.getCard = function(id) {
				if( id != '0' ) {
					$http.post('<?php echo base_url("apps/get-user-card")?>', {"id":id}).then(function(response){
						if( response.data.error == "false") {
							$('input[name="addcard"]').val(0);
							$('.pay-btn').val('Pay').prop('disabled', false);
							$('#cardname').val(response.data.cardName).prop('readonly', true);
							$('#ccnum').val(response.data.cardNumber).prop('readonly', true);
							$('#exp').val(response.data.cardExpiry).prop('readonly', true);
							$('#zipcode').val(response.data.cardZipcode).prop('readonly', true);
						}else{
							$('.pay-btn').val('Pay').prop('disabled', false);
							alert(response.data.error);
						}
					});
				} else {
					$('input[name="addcard"]').val(1);
					$('.pay-btn').val('Pay').prop('disabled', false);
					$('#cardname, #ccnum, #exp, #zipcode').val('').prop('readonly', false);
				}
			}
			$("#savedcards").change(function(){
				$('.pay-btn').val('Loading Card Data...').prop('disabled', true);
				$scope.getCard($(this).val());
			})
		});
	</script>