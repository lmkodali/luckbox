<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section">
		<div class="cur-tick-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<h1><img src="<?= base_url('assets/images/buy-ticket.png'); ?>" height="60" width="60" alt="CurrentTickets"> Current Tickets</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="cur-tick-table white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="table-responsive">
							<?php if( $cur_tick_data->num_rows() > 0 ): ?>
								<table class="table">
									<thead>
										<tr>
											<th>#</th>
											<th>Date Brought</th>
											<th>Ticket No.</th>
										</tr>
									</thead>
									<?php $i=1; foreach($cur_tick_data->result_array() as $ticket): ?>
										<tr>
											<td><?= $i; ?></td>
											<td><?= $ticket['DateBrought']; ?></td>
											<td><?= str_replace('-', ' ', $ticket['TicketNumbers']); ?></td>
										</tr>
									<?php $i++; endforeach; ?>
								</table>
							<?php else: ?>
								<p class="text-muted"><strong>Sorry !</strong> you have no tickets.</p>
							<?php endif; ?>
						</div>
						<?= anchor('user/buy', 'Buy More Tickets', ['class' => 'btn-my btn-blue']); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
