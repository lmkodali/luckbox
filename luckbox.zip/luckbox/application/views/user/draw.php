<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<section class="full-section" ng-app="drawApp" ng-controller="drawCtrl">
		<div class="draw-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="live-stream-video">
							<iframe width="100%" height="320" src="<?= $live_url; ?>" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="fill-draw white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<span class="luckey">
							<span class="first-match">{{firstwin}}</span>
						</span>
						<span class="luckey">
							<span class="second-match">{{secondwin}}</span>
						</span>
						<span class="luckey">
							<span class="third-match">{{thirdwin}}</span>
						</span>
						<span class="luckey">
							<span class="fourth-match">{{fourthwin}}</span>
						</span>
						<span class="luckey">
							<span class="fifth-match">{{fifthwin}}</span>
						</span>
					</div>
				</div>
			</div>
		</div><!-- End Fill Draw -->

		<div class="draw-tickets">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?php if( $draw_tickets->num_rows() > 0 ): ?>
						 	<div class="all-draw-tickets">
						 		<?php foreach( $draw_tickets->result() as $drawTicket ): ?>
						 			<table>
						 				<tr><td>
						 					<?= str_replace('-', '</td><td>', $drawTicket->TicketNumbers); ?>
						 				</td></tr>
						 			</table>
						 		<?php endforeach; ?>
						 	</div>
						<?php else: ?>
							<p class="text-muted"><strong>Sorry ! </strong> you have no tickets for draw.</p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div><!-- End Draw Tickets -->

	</section>

	<script type="text/javascript">
		//Create a angular drawApp
		var app = angular.module("drawApp", []);
		//Create angular controller drawCtrl
		app.controller("drawCtrl", function($scope, $http){
			//Initialize variables to blank
			$scope.firstwin = $scope.secondwin = $scope.thirdwin = $scope.fourthwin = $scope.fifthwin = '';
			//Function Hightlight First Match Of Ticket
			$scope.letHighlight = function(what, val){
				$(what).each(function(){
					if( Number($(this).text()) == val ) {
						$(this).addClass("highlight");
					}
				});
			}
			//Function Hightlight Other Match Of Ticket
			$scope.lethNextHighlight = function(what, val) {
				$(what).each(function(){
					if($(this).hasClass('highlight')) {
						if( Number($(this).next().text()) == val ) {
							$(this).next().addClass("highlight");
						}
					}
				});
			}
			//Function For get Winner Ticket Number
			function getWinTicket(){
				$http.post("<?= base_url('apps/get-winner-ticket'); ?>").then(function(response){
					if( response.data.error == "false" ) {
						$scope.firstwin 	= response.data.first;
						$scope.secondwin 	= response.data.second;
						$scope.thirdwin 	= response.data.third;
						$scope.fourthwin 	= response.data.fourth;
						$scope.fifthwin 	= response.data.fifth;
						//Hightlight if First Digits Matches
						if( response.data.first != "" ) {
							$scope.letHighlight('td:first-child', response.data.first);
						}
						//Hightlight second digit if first matches
						if( response.data.second != "" ) {
							$scope.lethNextHighlight('td:first-child', response.data.second);
						}
						//Hightlight third digit if second matches
						if( response.data.third != "" ) {
							$scope.lethNextHighlight('td:nth-child(2)', response.data.third);
						}
						//Hightlight fourth digit if third matches
						if( response.data.fourth != "" ) {
							$scope.lethNextHighlight('td:nth-child(3)', response.data.fourth);
						}
						//Hightlight fifth digit if fourth matches
						if( response.data.fifth != "" ) {
							$scope.lethNextHighlight('td:nth-child(4)', response.data.fifth);
						}
						//If all numbers of tickets fill check user win or lose
						if( response.data.fifth != "" ) {
							$http.post("<?= base_url('apps/check-user-ticket'); ?>").then(function(response){
								if(response.data.error == "false"){
									if( response.data.winner == "yes") {
										window.location.href="<?= base_url('user/win'); ?>";
									} else {
										window.location.href="<?= base_url('user/lose'); ?>";
									}
								} else {
									alert(response.data.error);
								}
							});
						}
					} else {
						alert(response.data.error);
					}
				});
			}
			//Check For Ticket Number On Every 3 Seconds
			setInterval( getWinTicket, 3000);
		});
	</script>