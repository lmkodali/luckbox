<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section">
		<div class="history-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-3">
						<img src="<?= base_url('assets/images/played.png'); ?>" height="60" width="60" alt="HistoryPlayed">
					</div>
					<div class="col-xs-9">
						<h4>Played Tickets</h4>
						<h1>History</h1>
						<p>
							This is for transparency,<br>
							options to see the blockchain<br>
							open ledger
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="ticket-table white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="table-responsive">
							<?php if( $history_data->num_rows() > 0 ): ?>
								<table class="table">
									<thead>
										<tr>
											<th>Date</th>
											<th>Draw #</th>
											<th>Blockchain #</th>
										</tr>
									</thead>
									<?php foreach( $history_data->result_array() as $tick ): ?>
										<tr>
											<td><?= $tick['DateBrought']; ?></td>
											<td><a href="javascript:void(0);"><?= $tick['TicketId']; ?></a></td>
											<td><?= str_replace('-', ' ', $tick['TicketNumbers']); ?></td>
										</tr>
									<?php endforeach; ?>
								</table>
							<?php else: ?>
								<p class="text-muted"><strong>Sorry !</strong> you have no history.</p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
