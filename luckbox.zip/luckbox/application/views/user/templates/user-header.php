<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<header>
	<div class="user-header">
		<div class="container">
			<div class="row">
				<div class="col-xs-6">
					<p class="text-left">
						<span class="open-nav">
							<img src="<?= base_url('assets/images/nav-icon.png'); ?>" alt="NavIcon">
						</span>
						<a href="<?= base_url(); ?>"><img class="user-logo" src="<?= base_url('assets/images/user-logo.png'); ?>" width="50" height="50" alt="LuckBux"></a>
					</p>
				</div>
				<div class="col-xs-6">
					<p class="text-right">
						<span><?= $ticket_count; ?></span> <a href="<?= base_url('user/tickets'); ?>"><img class="ticket-icon" width="30" height="30" src="<?= base_url('assets/images/user-ticket.png'); ?>" alt="Tickets"></a>
					</p>
				</div>
			</div>
		</div>
	</div>
</header>