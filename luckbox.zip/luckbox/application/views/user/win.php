<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<section class="full-section">
		<div class="draw-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="live-stream-video">
							<iframe width="100%" height="360" src="<?= $live_url; ?>" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="winning-ticket white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p>
							<img src="<?= base_url('assets/images/winning.png'); ?>" width="60" alt="Winner"> You have a winning ticket !
						</p>
						<div class="valued">
							<span class="valued-text">Valued at </span>
							<span class="valued-value">$<?= $valuedAmount; ?></span>
						</div>
						<table>
							<tr><td>
								<?= str_replace('-', '</td><td>', $winningTicket); ?>
							</td></tr>
						</table>
						<p>Be ready to pick up your phone to claim your win!</p>
					</div>
				</div>
			</div>
		</div>

	</section>