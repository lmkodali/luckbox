<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<section class="full-section" ng-app="myBuyApp" ng-controller="myBuyCtrl">
		<div class="buy-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-9">
						<h1><img src="<?= base_url('assets/images/buy-ticket.png'); ?>" width="50" height="50" alt="BuyTickets"> Buy Tickets</h1>
					</div>
					<div class="col-xs-3">
						<span>Price</span>
						<span class="price">$5.00</span>
					</div>
				</div>
			</div>
		</div><!-- End Buy Top -->
		<div class="pick-ticket white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?= get_msg(); ?>
						<ul class="nav nav-pills">
							<li class="active"><a data-toggle="pill" href="#pick">Pick</a></li>
							<li><a data-toggle="pill" href="#random"><img src="<?= base_url('assets/images/random.png'); ?>"> Random</a></li>
						</ul>
						<div class="tab-content">
							<div id="pick" class="tab-pane fade in active">
								<div class="ticket-pick-form">
									<p>Ticket Number</p>
									<div class="row">
										<div class="col-xs-8">
											<?php
												# Generates Five Fields
												for( $i=0; $i<5; $i++ ):
												?>
													<input type="number" ng-model="ticketnum<?= $i; ?>" class="ticketnum">
												<?php
												endfor;
											?>
											<div class="clearfix"></div>
										</div>
										<div class="col-xs-4">
											<button name="pick" class="btn-my btn-blue btn-pick" ng-click="addSpinTicket()">Pick</button>
										</div>
									</div>
								</div><!-- End Ticket Pick Form -->
							</div>
							<div id="random" class="tab-pane fade">
								<div class="ticket-pick-random">
									<p>Ticket Number</p>
										<?php
											# Generate Five Span Fields
											for( $i=0; $i<5; $i++ ):
											?>
												<span class="ticketspinnum"  id="random<?php echo $i; ?>" ng-bind="ticketspin<?= $i ?>"></span>
											<?php
											endfor;
										?>
										<button name="pick" id="spin-it" ng-click="generateTicket()"><img src="<?= base_url('assets/images/spin.png'); ?>"> Spin</button>
										<div class="clearfix"></div>
									<a class="btn-my btn-disabled btn-choose-num" ng-click="addSpinTicket('spin')" href="javascript:void(0)">Choose this number</a>
								</div><!-- End Ticket Pick Random -->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="ticket-added">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="new-tickets">
							<div ng-repeat="x in mytickets">
								<table>
									<tr>
										<td>{{x.Ticket1}}</td>
										<td>{{x.Ticket2}}</td>
										<td>{{x.Ticket3}}</td>
										<td>{{x.Ticket4}}</td>
										<td>{{x.Ticket5}}</td>
									<tr>
								</table>
								<a href="javascript:void(0);" ng-click="deleteTicket(x.TicketId)">&times;</a>
							</div>
						</div><!-- End New Ticket -->
					</div>
				</div>
			</div>
		</div><!-- End Add Ticket -->

		<div class="go-for-pay white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?= form_open('user/buy', ['autocomplete' => 'off']); ?>
							<p>
								<span class="pull-left">
									Tickets <input type="text" name="ticketcounts" class="ticket-count" value="{{ticketnumbers}}" readonly>
								</span>
								<span class="pull-right">
									<b>Total</b> $<input type="text" name="totaldollar" class="total-dollar" value="{{ticketamount}}" readonly>
								</span>
							</p>
							<div class="clearfix"></div>
							<?= form_submit('goforpay', 'Continue to payment', ['class' => 'btn-my btn-disabled']); ?>
						<?= form_close(); ?>
					</div><!-- End Column -->
				</div>
			</div>
		</div><!-- End go for pay -->
	</section>
	<script type="text/javascript">
		$(function(){
			$('.ticketnum').each(function(){
				$(this).keyup(function () {
				    if (this.value.length == 2) {
				      $(this).next('input').focus();
				    }
				});
			})
		})
		//Create angular app myBuyApp
		var app = angular.module('myBuyApp', []);
		//Configure for unhandled rejection
		app.config(['$qProvider', function ($qProvider) {
		    $qProvider.errorOnUnhandledRejections(false);
		}]);
		//Create angular Controller myBuyCtrl
		app.controller('myBuyCtrl', ['$scope','$http', function($scope, $http) {
			//Autofocus Field First
			$('.ticket-pick-form input:first-child').focus();
			//Get Number of pending payment tickets of user
			$scope.numberOfTickets = function() {
				$http.post("<?= base_url('apps/get-tickets-number'); ?>").then(function(response) {
					$scope.ticketnumbers = response.data.NumberOfTickets;
					$scope.ticketamount = $scope.ticketnumbers*5;
					//Enabled button if payment is not zero
					if($scope.ticketnumbers != 0){
						$(".go-for-pay .btn-my").prop('disabled', false).removeClass('btn-disabled').addClass('btn-blue');
					} else {
						$(".go-for-pay .btn-my").prop('disabled', true).removeClass('btn-blue').addClass('btn-disabled');
					}
				});
			}
			//Show all tickets whose status is pending for payment
			$scope.getAllTickets = function() {
				$http.post("<?= base_url('apps/get-added-tickets'); ?>").then(function(response) {
			        $scope.mytickets = response.data.tickets;
			        $scope.numberOfTickets();
			        $("html, body").animate({ scrollTop: $(document).height() }, 1000);
			    });
			}
			//Generate random number
			$scope.radomNum = function() {
				return Math.floor(Math.random() * 90 + 10);
			}
			//On click spin generate random ticket number
			$scope.generateTicket = function() {
				//Generate Random Numbers for each Fields
				$scope.ticketspin0 = $scope.radomNum();
				$scope.ticketspin1 = $scope.radomNum();
				$scope.ticketspin2 = $scope.radomNum();
				$scope.ticketspin3 = $scope.radomNum();
				$scope.ticketspin4 = $scope.radomNum();
				//Set Attribute Data Count for All Random Fields
				$('#random0').attr('data-count', $scope.ticketspin0);
				$('#random1').attr('data-count', $scope.ticketspin1);
				$('#random2').attr('data-count', $scope.ticketspin2);
				$('#random3').attr('data-count', $scope.ticketspin3);
				$('#random4').attr('data-count', $scope.ticketspin4);
				//Animate Each Random Field to The Value
				$('.ticketspinnum').each(function() {
				    var $this = $(this),
					countTo = $this.attr('data-count');
					$({countNum: $this.text()}).animate({
						countNum: countTo
				  	},
					{
						duration: 1500,
						easing:'linear',
						step: function() {
						  $this.text(Math.floor(this.countNum));
						},
						complete: function() {
						  $this.text(this.countNum);
						}
					});  
				});
				//Disable button after adding ticket
				$(".ticket-pick-random .btn-my").removeClass("btn-disabled").addClass("btn-blue");
			}
			//Adding ticket number to database from generate and pick ticket
			$scope.addSpinTicket = function(type = 'new') {
				//Data if User enter ticket numbers
				if( type == 'new'){
					$scope.ticketData = {"TicketNumber": $scope.ticketnum0 + "-" + $scope.ticketnum1 + "-" + $scope.ticketnum2 + "-" + $scope.ticketnum3 + "-" + $scope.ticketnum4};
				} else {
					//Data if user Spin and generate ticket numbers
					$scope.ticketData = {"TicketNumber": $scope.ticketspin0 + "-" + $scope.ticketspin1 + "-" + $scope.ticketspin2 + "-" + $scope.ticketspin3 + "-" + $scope.ticketspin4};
				}
				//Adding the new ticket
				$http.post("<?= base_url('apps/add-new-ticket'); ?>", $scope.ticketData).then(function(response) {
					$(".ticket-pick-form .ticketnum").val('');
					$scope.ticketspin0 = $scope.ticketspin1 = $scope.ticketspin2 = $scope.ticketspin3 = $scope.ticketspin4 = $scope.ticketnum0 = $scope.ticketnum1 = $scope.ticketnum2 = $scope.ticketnum3 = $scope.ticketnum4 = '';
					$(".ticket-pick-random .btn-my").addClass("btn-disabled").removeClass("btn-blue");
			        $scope.getAllTickets();
			    });
			}
			//Delete the ticket with the id provided
			$scope.deleteTicket = function( id ) {
				$http.post("<?= base_url('apps/delete-ticket'); ?>", {"id": id}).then(function(response) {
			        $scope.getAllTickets();
			    });
			}
			//On start get all pending tickets
			$scope.getAllTickets();
		}]);
	</script>
