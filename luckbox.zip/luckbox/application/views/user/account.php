<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section" ng-app="myAcApp" ng-controller="myAcController">
		<div class="account-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<h1> <img src="<?= base_url('assets/images/account.png'); ?>" height="60" width="60" alt="Account"> Account</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="user-ac-id white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-2">
						<?php
							$user_profile = ( isset($fb_logout) ) ? $user_pic : base_url('assets/images/'. $user_pic );
						?>
						<img src="<?= $user_profile; ?>" height="60" width="60" alt="Profile">
					</div>
					<div class="col-xs-10">
						<span class="user-name"><?= $user_name; ?></span><br>
						<?php if( isset($fb_logout) ): ?>
							<span class="fb-id">Facebook ID: <?= $fb_oid; ?></span>
						<?php else: ?>
							<span class="user-email"><?= $user_email; ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="user-ac-contact white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p>
							<span class="pull-left">CONTACT</span>
							<span class="pull-right">
								<a class="edit-contact" ng-click="editTheDetail('contact')" href="javascript:void(0);">Edit</a>
								<a class="upt-contact" ng-click="updateContactNum()" href="javascript:void(0);">Update</a>
							</span>
						</p>
						<div class="clearfix"></div>
						<input type="text" class="only-read u-contact" id="phone" ng-model="userPhone" value="{{userPhone}}" autocomplete="off" readonly>
						<!-- <span class="contact-number">+1 555 342 2342</span> -->
					</div>
				</div>
			</div>
		</div>
		<div class="user-ac-location white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p>
							<span class="pull-left">LOCATION</span>
							<span class="pull-right">
								<a class="edit-locat" ng-click="editTheDetail('locat')" href="javascript:void(0);">Edit</a>
								<a class="upt-locat" ng-click="updateUserLoc()" href="javascript:void(0);">Update</a>
							</span>
						</p>
						<div class="clearfix"></div>
						<!-- <span class="contact-number">Ottawa, ON</span> -->
						<input type="text" class="only-read u-locat" ng-model="userLocation" value="{{userLocation}}" autocomplete="off" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="deactivate-btn">
			<p class="text-center">
				<?= anchor('user/deactivate', 'Deactivate', ["onclick" => "return(confirm('Sure want to deactivate Account. You will be loggedout.'))", 'class' => 'btn btn-default btn-lg']); ?>
			</p>
		</div>
	</section>

	<script type="text/javascript">
		var app = angular.module('myAcApp', []);

		app.controller('myAcController', ['$scope', '$http', function($scope, $http){
			//Get Your Account Details
			$scope.getAcDetails = function() {
				$http.post('<?= base_url('apps/get-acc-details'); ?>').then(function(response){
					$scope.userPhone = response.data.userPhone;
					$scope.userLocation = response.data.userLocation;
				});
			}
			//For enable field to edit and update
			$scope.editTheDetail = function(param){
				$(".u-" + param ).removeClass('only-read').removeAttr('readonly');
				$(".edit-" + param ).hide();
				$(".upt-" + param ).show();
			}
			//Update Contact Number Information
			$scope.updateContactNum = function(){
				$(".upt-contact").text('Updating..');
				$http.post('<?= base_url('apps/update-contact-detail'); ?>', {"contactNum": $scope.userPhone}).then(function(response){
					if( response.data.available == 0){alert('ERROR ! Mobile Number Already Exist,')}
					$(".u-contact").addClass('only-read').attr('readonly', 'readonly');
					$(".edit-contact").show();
					$(".upt-contact").text('Update').hide();
					$scope.getAcDetails();
				});
			}
			//Update Location Information
			$scope.updateUserLoc = function(){
				$(".upt-locat").text('Updating..');
				$http.post('<?= base_url('apps/update-location-detail'); ?>', {"userLocat": $scope.userLocation}).then(function(response){
					$(".u-locat").addClass('only-read').attr('readonly', 'readonly');
					$(".edit-locat").show();
					$(".upt-locat").text('Update').hide();
					$scope.getAcDetails();
				});
			}
			//Call function to get Details on page Load
			$scope.getAcDetails();
		}]);
	</script>