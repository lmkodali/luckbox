<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	<section class="full-section">
		<div class="draw-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<div class="live-stream-video">
							<iframe width="100%" height="360" src="<?= $live_url; ?>" frameborder="0" allowfullscreen></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="winner-details white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<table>
							<tr><td>
								<?= str_replace('-', '</td><td>', $winnerTicket); ?>	
							</td></tr>
						</table>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-4">
						<img class="img-responsive" src="<?= base_url('assets/images/default.png'); ?>">
					</div>
					<div class="col-xs-8">
						<h3>$<?= $winnerAmount; ?></h3>
						<p><?= $winnerName; ?></p>
						<p><?= $winnerLocation; ?></p>
					</div>
				</div>
			</div>
		</div>

		<div class="buy-more">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?= anchor('user/buy', 'Buy tickets for next draw', ['class' => 'btn-my btn-blue']); ?>
						<?= anchor(base_url(), 'Exit draw', ['class' => 'btn-my btn-white']); ?>
					</div>
				</div>
			</div>
		</div>

	</section>