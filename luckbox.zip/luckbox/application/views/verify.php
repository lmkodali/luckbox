<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section" ng-app="myVerifyApp" ng-controller="myVerifyController">
		<?= get_msg(); ?>
		<div class="verify-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<h1 class="text-center">Phone Verification</h1>
					</div>
				</div>
			</div>
		</div><!-- End Verify Top -->
		<div class="verify-form white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p>
							<strong>
								We sent verification code to 
								<a href="javascript:void(0);" class="edit" ng-click="editPhone()">Edit</a>
								<br>
								<input type="text" class="only-read p-num" ng-model="phoneNumber" value="{{phoneNumber}}" readonly>
								<br>
								<a href="javascript:void(0);" class="update" ng-click="updatePhone()">Update</a>
								<a href="javascript:void(0);" class="cancel" ng-click="cancelPhone()">Cancel</a>
							</strong>
						</p>
						<p>Didn't get it? <a href="javascript:void(0);" ng-click="resendCode()">Resend Code</a></p>
						<?= form_open('verify-otp', ['autocomplete' => 'off']); ?>
							<div class="form-group">
								<?php
									echo form_label('<strong>6-Digit Verification Code</strong>', 'code');
									echo form_input([
											'type'		=> 'text',
											'name'		=> 'code',
											'id'		=> 'code',
											'maxlength'	=> 6,
											'pattern'	=> '\d*',
											'class'		=> 'form-control',
											'required'	=> 'required'
										]);
								?>
							</div>
							<div class="form-group">
								<?=
									form_submit([
											'name'	=> 'verify',
											'class'	=> 'btn-my btn-blue',
											'value'	=> 'Verify'
										]);
								?>
							</div>
						<?= form_close(); ?>
					</div><!-- End Column -->
				</div>
			</div>
		</div><!-- End Verify Form -->
	</section>

	<script type="text/javascript">
		$(".p-num").mask("999 999 9999", {clearIfNotMatch: true, placeholder:""});
		// Create angular app myVerifyApp
		var app = angular.module('myVerifyApp', []);
		// Create angular controller myVerifyController
		app.controller('myVerifyController', ['$scope', '$http', function($scope, $http){
			// Function for get user phone number
			function getUserPhone() {
				$http.post('<?= base_url('outer/get-user-phone'); ?>').then(function(response){
					if( response.data.error == "false" ) {
						$scope.phoneNumber = response.data.phoneNumber;
					}
				});
			}
			// Resend verification code
			$scope.resendCode = function() {
				$http.post('<?= base_url('outer/resend-verify-code'); ?>').then(function(response){
						if( response.data.error == "false" ) {
							alert('Vefication code sent again.');
						} else {
							alert('Unable to send verification code again.');
						}
					});
			}
			//Edit phone number
			$scope.editPhone = function() {
				$('.edit').hide();
				$('.update, .cancel').show();
				$('.p-num').removeClass('only-read').removeAttr('readonly').val('').focus();
			}
			//Cancel Edit phone number
			$scope.cancelPhone = function() {
				$('.edit').show();
				$('.update, .cancel').hide();
				getUserPhone();
				$('.p-num').addClass('only-read').attr('readonly', 'readonly').val($scope.phoneNumber);
			}
			//Update phone number and send verification code to that
			$scope.updatePhone = function() {
				$('.update').text('Updating');
				$http.post('<?= base_url('outer/update-verify-phone'); ?>', {
					"newphone": $scope.phoneNumber,
					"id": <?= $this->session->userdata('userid'); ?>
				}).then(function(response){
					if( response.data.error == "false"){
						$('.edit').show();
						$('.update, .cancel').hide();
						getUserPhone();
						$('.p-num').addClass('only-read').attr('readonly', 'readonly').val($scope.phoneNumber);
						$('.update').text('Update');
					} else {
						$('.update').text('Update');
						alert(response.data.error);
					}
				});
			}
			// Get user phone number
			getUserPhone();
		}]);
	</script>