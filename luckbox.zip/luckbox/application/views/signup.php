<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

	<section class="full-section">
		<div class="form-top">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p><a href="javascript:history.back(-1);"><i class="fa fa-angle-left"></i> Back</a></p>
						<h1>Sign Up</h1>
					</div>
				</div>
			</div>
		</div>
		<div class="main-form white-with-shade">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<?php
							echo (validation_errors() != false) ? '<div class="val-errors">'.validation_errors().'</div>' : '' ;
							echo form_open('signup', ['autocomplete' => 'off']);
							?>
							<div class="form-group">
								<?php
									echo form_label('Name', 'name');
									echo form_input([
											'name'		=> 'name',
											'id'		=> 'name',
											'value'		=> set_value('name'),
											'class'		=> 'form-control',
											'required'	=> 'required'
										]);
								?>
							</div>
							<div class="form-group">
								<?php
									echo form_label('Email', 'email');
									echo form_input([
											'type'		=> 'email',
											'name'		=> 'email',
											'value'		=> set_value('email'),
											'id'		=> 'email',
											'class'		=> 'form-control',
											'required'	=> 'required'
										]);
								?>
							</div>
							<div class="form-group">
								<?= form_label('Password', 'password'); ?>
								<div class="input-group">
									<?=
										 form_password([
												'name'		=> 'password',
												'id'		=> 'password',
												'class'		=> 'form-control',
												'required'	=> 'required'
											]);
									?>
									<span class="input-group-addon view-pass"><i class="fa fa-eye"></i></span>
								</div>
							</div>
							<div class="form-group">
								<?= form_label('Phone', 'phone'); ?>
								<div class="input-group">
									<span class="input-group-addon"><?= COUNTRY_CODE; ?></span>
									<?=
										form_input([
											'name'		=> 'phone',
											'value'		=> set_value('phone'),
											'id'		=> 'phone',
											'class'		=> 'form-control',
											'required'	=> 'required'
										]);
									?>
								</div>
							</div>
							<div class="form-group">
								<?= 
									form_submit([
											'name' 	=> 'signup',
											'value'	=> 'Sign Up',
											'class'	=> 'btn-my btn-blue'
										]);
								?>
							</div>
						<?= form_close(); ?>
					</div>
				</div>
			</div>
		</div>
		<div class="form-bottom">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<p>
							<img src="assets/images/signup.png" height="38" width="50" alt="SignUp">
							Already have an account? <?= anchor('login', 'Log In'); ?>
							<br>
							<br>
							By tapping "Sign Up" you agree to <?= anchor('terms', 'terms &amp; conditions.'); ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>

