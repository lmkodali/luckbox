<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	# Date and Time For Day Before Draw Setted Date
	$thisToday = date("d/m/Y");
	$formateSetDay = strtotime($closing_date.' '.date("Y"));
	$lastDay = date('d/m/Y', strtotime("-1 day", $formateSetDay));
	#Formate closing date
	$closeDateNew = date('d/m/Y', strtotime($closing_date.' '.date("Y")));
	$timeArr = explode(' ', $draw_time);
	$closeTimeNew = date("g A T", strtotime($timeArr[0]));
	$settedTime = strtotime(str_replace('/', '-', $closeDateNew).' '.$timeArr[0]);
	$counterTime = date("M j, Y H:i:s", $settedTime);
?>

	<section class="full-section">
		<div class="top-blue-area">
			<div class="container">
				<div class="logo-nav-login">
					<div class="row">
						<div class="col-xs-3">
							<?php if( $user_loggedin ): ?>
								<p class="text-left">
									<span class="open-nav">
										<img src="<?= base_url('assets/images/nav-icon.png'); ?>" height="40" width="40" alt="NavIcon">
									</span>
								</p>
							<?php endif; ?>
						</div>
						<div class="col-xs-6">
							<p class="text-center">
								<a href="<?= base_url(); ?>"><img src="<?= base_url('assets/images/logo-1.png'); ?>" height="64" width="64" alt="LuckBux"></a>
							</p>
						</div>
						<div class="col-xs-3">
							<?php if( $user_loggedin == FALSE ): ?>
								<p class="text-right"><?= anchor('login', 'Log In'); ?></p>
							<?php endif; ?>
						</div>
					</div>
				</div><!-- End Logo Nav Login -->
				<?= get_msg(); ?>
				<div class="current-jackpot">
					<?php if( ($thisToday === $lastDay) || ($thisToday === $closeDateNew) ):?>
						<p>
							<span class="pull-left"><strong>Current Jackpot</strong></span>
							<span class="pull-right"><?= $closing_date.', '.$closeTimeNew; ?></span>
						</p>
						<div class="clearfix"></div>
					<?php else: ?>
						<p><strong>Current Jackpot </strong></p>
					<?php endif; ?>
					<div class="current-jackpot-inner">
						<span class="odometer-digit">$</span>
						<div id="odometer" class="odometer"></div>
					</div>
					<?php if( ($thisToday === $lastDay) || ($thisToday === $closeDateNew) ):?>
						<h3 class="text-center">Countdown</h3>
					<?php else: ?>
						<div class="progress">
							<div class="progress-bar" role="progressbar" aria-valuenow="<?= $total_amount; ?>"
							<?php
								$pbWidth = ( $total_amount * 100 ) / ( $target_amount );
							?>
							aria-valuemin="0" aria-valuemax="<?= $target_amount; ?>" style="width:<?= $pbWidth; ?>%">
								<span class="sr-only"><?= $pbWidth; ?>% Complete</span>
							</div>
						</div>
						<p>
							<span class="pull-left">GOAL $<?= $target_amount; ?></span>
							<span class="pull-right">EST DRAW <?= $closing_date; ?></span>
						</p>
						<div class="clearfix"></div>
					<?php endif; ?>
				</div><!-- End Current Jackpot -->
				<?php if( ($thisToday === $lastDay) || ($thisToday === $closeDateNew) ):?>
						<div class="countdown-timer">
							<div class="row">
								<div class="col-xs-12">
									<div id="demo-count"></div>
									<script>
										// Set the date we're counting down to
										var countDownDate = new Date("<?= $counterTime; ?>").getTime();

										function pad(n)
										{
										    return (n < 10) ? ("0" + n) : n;
										}

										// Update the count down every 1 second
										var x = setInterval(function() {

										    // Get todays date and time
										    var now = new Date().getTime();
										    
										    // Find the distance between now an the count down date
										    var distance = countDownDate - now;
										    
										    // Time calculations for days, hours, minutes and seconds
										    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
										    var hours = Math.floor(distance / (1000 * 60 * 60));
										    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
										    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
										    
										    // Output the result in an element with id="demo"
										    document.getElementById("demo-count").innerHTML = 
										    '<span class="count-hours">' + pad(hours) +
											'</span> : <span class="count-minute">' + pad(minutes) +
											'</span> : <span class="count-seconds">' + pad(seconds) +
											'</span>';
										    
										    // If the count down is over, write some text 
										    if (distance < 0) {
										        clearInterval(x);
										        document.getElementById("demo-count").innerHTML = "DRAW TIME";
										    }
										}, 1000);
										</script>
								</div>
							</div>
						</div>
					<?php
					endif;
				?>
				<?php if( $user_loggedin == FALSE ): ?>
					<div class="login-with-section">
						<a href="<?= $fb_login_url; ?>" class="btn-my btn-fb">
							<i class="fa fa-facebook"></i> Continue With Facebook
						</a>
						<?=
							anchor('signup', 'Create An Account', ['class' => 'btn-my btn-create-ac']);
						?>
					</div><!-- End Login With -->
				<?php endif; ?>
			</div>
		</div><!-- End top Blue -->
		<?php if( $user_loggedin ): ?>
			<div class="bottom-ticket white-with-shade">
				<div class="container">
					<div class="row">
						<div class="col-xs-12">
							<?php if( $ticket_count  == 0 ): ?>
								<p class="text-center">You have no tickets.</p>
							<?php else: ?>
								<p>
									<span class="pull-left">Total Tickets</span>
									<span class="pull-right">
										<img src="<?= base_url('assets/images/tickets.png'); ?>" height="20" width="20" alt="Tickets"> <?= $ticket_count; ?>
									</span>
								</p>
								<div class="clearfix"></div>
							<?php endif; ?>
								<?= anchor('user/buy', 'Buy Tickets', ['class' => 'btn-my btn-blue']); ?>
						</div>
					</div>
				</div>
			</div>
			<?php if( $ticket_count  != 0 ): ?>
				<div class="all-tickets">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
								<?php
									foreach($success_ticket->result_array() as $ticket):
									?>
									<table>
										<tr><td>
											<?= str_replace('-', '</td><td>', $ticket['TicketNumbers']); ?>
										</td></tr>
									</table>
									<?php
									endforeach;
								?>
							</div>
						</div>
					</div>
				</div>
			<?php
				endif;
			endif;
		?>
	</section>

	<div class="pre-screen-loader">
		<div class="pre-screen-logo">
			<img src="<?= base_url('assets/images/loading-logo.png'); ?>" height="120" width="120" alt="LuckBux">
		</div>
	</div>

	<?php
		//Draw Participation Set
		// if( isset($total_amount) && isset($target_amount) && isset($user_set_draw) && $user_set_draw == 'not' && $ticket_count != 0 ):
		// 	if( $total_amount >= $target_amount ):
		if( ($thisToday === $lastDay) && isset($user_set_draw) && $user_set_draw == 'not' && $ticket_count != 0 ): ?>
			<div class="draw-participate">
				<div class="container">
					<div class="row">
						<div class="draw-inner">
							<div class="current-jackpot">
								<p><strong>Current Jackpot</strong></p>
								<table>
									<tr >
										<td>$</td>
										<?php
											$amount = str_split( str_pad($total_amount, 6, '0', STR_PAD_LEFT) ); 
											for( $i=0; $i < count($amount); $i++ )
											{
												echo '<td>'.$amount[$i].'</td>';
											}
										?>
									</tr>
								</table>
								<div class="progress">
									<div class="progress-bar" role="progressbar" aria-valuenow="<?= $total_amount; ?>"
									aria-valuemin="0" aria-valuemax="<?= $target_amount; ?>" style="width:100%">
										<span class="sr-only">100% Complete</span>
									</div>
								</div>
								<p><span class="pull-left">GOAL $<?= $target_amount; ?></span><span class="pull-right">100%</span></p>
								<div class="clearfix"></div>
							</div><!-- End Current Jackpot -->
							<h2 class="text-center">Draw Set for</h2>
							<h4 class="text-center"><?= $closing_date.' '.$draw_time; ?></h4>
							<a href="<?= base_url('user/draw-set-to/confirm/'.$this->session->userdata('userid')); ?>" class="btn-my btn-blue">Confirm my attendance</a>
							<p class="text-center"><small>Can't make this draw?</small></p>
							<a href="<?= base_url('user/draw-set-to/next/'.$this->session->userdata('userid')); ?>" class="btn-my btn-next-draw">Defer to next draw</a>
						</div>
					</div>
				</div>
			</div>
		<?php 
			// endif;
		endif;
		
	?>

<script>
 $(document).ready(function() {
	setTimeout(function(){
    odometer.innerHTML = <?php echo $total_amount; ?>;
	}, 2000);
		 
	setInterval(ajaxCall, 5000); //300000 MS == 5 minutes

	function ajaxCall() {
	
		$.post("<?php echo base_url().'local/get_total_amount' ?>",
		function(data, status){
			odometer.innerHTML = data;
		});
	}
})
</script>