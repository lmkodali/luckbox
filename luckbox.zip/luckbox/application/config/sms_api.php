<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
|  SMS API details
| -------------------------------------------------------------------
|
| To get an plivo auth id and auth token please login
| at http://plivo.com.
|
|  plivo_auth_id              string   Your Plivo Auth Id.
|  plivo_auth_token           string   Your Plivo Auth Token.
*/

$config['plivo_auth_id']            = 'MAOTRJYZJJZTFMZGYWND';
$config['plivo_auth_token']         = 'MDJlMGYzZmRhMzkzMTNmOTQ5MzE3MDhlZTliOGQ2';