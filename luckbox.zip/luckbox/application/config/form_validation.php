<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	$config = array(

			//User login validation rules
			'user_login' => array(
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.'
	                	)
					),

					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter password.'
	                	)
					)
				),

			//User signup validation rules
			'user_signup' => array(

					array(
						'field' 	=> 'name',
						'label' 	=> 'Name',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter your name.'
	                	)
					),
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email|is_unique[users.Email]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.',
							'is_unique' 	=> 'Email address already exist.'
	                	)
					),
					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|required|min_length[8]|callback_password_check',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter password.',
							'min_length'	=> 'Password should be atleast 8 digit.',
							'password_check'	=> 'Password must contain at least 1 Number 1 Capital and 1 Symbol.'
	                	)
					),
					array(
						'field' 	=> 'phone',
						'label' 	=> 'Phone',
						'rules' 	=> 'trim|required|exact_length[12]|is_unique[users.Phone]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter your phone number.',
	                        'exact_length' 		=> 'Please enter valid phone number.',
							'is_unique' 	=> 'Mobile number already exist.'
	                	)
					)
				),

			//Admin login validation rules
			'auth_login' => array(
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.'
	                	)
					),

					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter password.'
	                	)
					)
				),

			//Payment making validation rules
			'make_payment' => array(
					array(
						'field' 	=> 'cardname',
						'label' 	=> 'Name on Card',
						'rules' 	=> 'trim|required|alpha_numeric_spaces',
						'errors' 	=> array(
	                        'required' 				=> 'Please enter name on card.',
							'alpha_numeric_spaces' 	=> 'Only alpha numeric character allowed in card name.'
	                	)
					),

					array(
						'field' 	=> 'ccnum',
						'label' 	=> 'Credit Card Number',
						'rules' 	=> 'trim|required|alpha_numeric_spaces|exact_length[19]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter credit card number.',
							'alpha_numeric_spaces' 	=> 'Please enter valid card number.',
							'exact_length' 	=> 'Please enter valid card number.'
	                	)
					),

					array(
						'field' 	=> 'exp',
						'label' 	=> 'Expire Date',
						'rules' 	=> 'trim|required|callback_check_expiry',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter expiry date.',
							'check_expiry' 	=> 'Please enter valid expriy date in MM/YY formate.',
	                	)
					),

					array(
						'field' 	=> 'cvvnum',
						'label' 	=> 'CVV Number',
						'rules' 	=> 'trim|required|numeric|max_length[4]|min_length[3]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter cvv number.',
							'numeric' 	=> 'Please enter valid cvv number.',
							'max_length' 	=> 'Please enter valid cvv number.',
							'min_length' 	=> 'Please enter valid cvv number.'
	                	)
					),

					array(
						'field' 	=> 'zipcode',
						'label' 	=> 'Billing Zip Code',
						'rules' 	=> 'trim|required|alpha_numeric|exact_length[6]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter zipcode.',
							'numeric' 	=> 'Please enter valid zipcode.',
							'exact_length' 	=> 'Please enter valid zipcode.'
	                	)
					)

				),

			'auth_options'	=> array(

					array(
						'field' 	=> 'target',
						'label' 	=> 'Target Amount',
						'rules' 	=> 'trim|required|numeric',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter target amount.',
							'numeric' 	=> 'Please enter valid amount.'
	                	)
					),

					array(
						'field' 	=> 'date',
						'label' 	=> 'Date',
						'rules' 	=> 'trim|required|numeric',
						'errors' 	=> array(
	                        'required' 		=> 'Please choose date from dropdown.',
							'numeric' 	=> 'Date is not valid.'
	                	)
					),

					array(
						'field' 	=> 'month',
						'label' 	=> 'Month',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 		=> 'Please choose month from dropdown.'
	                	)
					),

					array(
						'field' 	=> 'adminmail',
						'label' 	=> 'Admin Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please Enter admin Email.',
	                        'valid_email' 	=> 'Please enter valid Admin email.'
	                	)
					)
				),

			//User signup validation rules
			'user_edit' => array(

					array(
						'field' 	=> 'name',
						'label' 	=> 'Name',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter your name.'
	                	)
					),
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.'
	                	)
					),
					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|min_length[8]',
						'errors' 	=> array(
							'min_length'	=> 'Password should be atleast 8 digit.',
							'password_check'	=> 'Password must contain at least 1 Number 1 Capital and 1 Symbol.'
	                	)
					),
					array(
						'field' 	=> 'phone',
						'label' 	=> 'Phone',
						'rules' 	=> 'trim|required|exact_length[12]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter your phone number.',
	                        'exact_length' 		=> 'Please enter valid phone number.'
	                	)
					)
				),

			//User signup validation rules
			'auth_profile' => array(

					array(
						'field' 	=> 'name',
						'label' 	=> 'Name',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter your name.'
	                	)
					),
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.'
	                	)
					),
					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|min_length[8]',
						'errors' 	=> array(
							'min_length'	=> 'Password should be atleast 8 digit.'
	                	)
					),
					array(
						'field' 	=> 'phone',
						'label' 	=> 'Phone',
						'rules' 	=> 'trim|required|exact_length[12]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter your phone number.',
	                        'exact_length' 		=> 'Please enter valid phone number.'
	                	)
					)
				),

			//Admin Draw validation
			'auth_draw' => array(
					array(
						'field' 	=> 'activedraw',
						'label' 	=> 'Draw',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 		=> 'Please Choose draw if not have create one.',
	                        'is_unique' 	=> 'Draw name already exist.'
	                	)
					)
				),

			//User signup validation rules
			'add_auth' => array(

					array(
						'field' 	=> 'name',
						'label' 	=> 'Name',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter admin name.'
	                	)
					),
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email|is_unique[auth.Email]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.',
							'is_unique' 	=> 'Email address already exist.'
	                	)
					),
					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|required|min_length[8]|callback_password_check',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter password.',
							'min_length'	=> 'Password should be atleast 8 digit.',
							'password_check'	=> 'Password must contain at least 1 Number 1 Capital and 1 Symbol.'
	                	)
					),
					array(
						'field' 	=> 'phone',
						'label' 	=> 'Phone',
						'rules' 	=> 'trim|required|exact_length[12]|is_unique[auth.Phone]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter your phone number.',
	                        'exact_length' 		=> 'Please enter valid phone number.',
							'is_unique' 	=> 'Mobile number already exist.'
	                	)
					)
				),

			//edit admin user
			'edit_auth' => array(

					array(
						'field' 	=> 'name',
						'label' 	=> 'Name',
						'rules' 	=> 'trim|required',
						'errors' 	=> array(
	                        'required' 	=> 'Please enter admin name.'
	                	)
					),
					array(
						'field' 	=> 'email',
						'label' 	=> 'Email',
						'rules' 	=> 'trim|required|valid_email',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter email.',
							'valid_email' 	=> 'Please enter valid email.'
	                	)
					),
					array(
						'field' 	=> 'password',
						'label' 	=> 'Password',
						'rules' 	=> 'trim|min_length[8]',
						'errors' 	=> array(
							'min_length'	=> 'Password should be atleast 8 digit.',
							'password_check'	=> 'Password must contain at least 1 Number 1 Capital and 1 Symbol.'
	                	)
					),
					array(
						'field' 	=> 'phone',
						'label' 	=> 'Phone',
						'rules' 	=> 'trim|required|exact_length[12]',
						'errors' 	=> array(
	                        'required' 		=> 'Please enter your phone number.',
	                        'exact_length' 		=> 'Please enter valid phone number.'
	                	)
					)
				),


		);